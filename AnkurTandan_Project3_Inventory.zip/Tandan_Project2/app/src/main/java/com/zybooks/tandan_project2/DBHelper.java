package com.zybooks.tandan_project2;

// import statements
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

/** this class is a helper class that manages database creation and is used to store inventory and user data.
 * It also has queries for creating tables, inserting, deleting and updating inventory items. It is interface
 * for other parts of the application to access the databse */
public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "UserInventory.db";
    private static final int DATABASE_VERSION = 1;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
// called when the database is created for first time.  Creation of tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "username TEXT," +
                        "password TEXT);"
        );
        db.execSQL(
                "CREATE TABLE inventory (" +
                        "itemID INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "name TEXT," +
                        "quantity INTEGER);"
        );
    }

    // called when the database need to be upgraded.  Best practice.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS inventory");
        onCreate(db);
    }

    // Add item
    public boolean addItem(String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("quantity", quantity);
        long id = db.insert("inventory", null, values);
        return id != -1;
    }

    // get all items
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM inventory", null);
    }

    // update inventory quantity for an item.  passing itemID
    public boolean updateItemQuantity(int itemID, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("quantity", newQuantity);
        return db.update("inventory", values, "itemID = ?", new String[] {String.valueOf(itemID)}) > 0;
    }

    // deleting an item or hitting the 'X'
    public boolean deleteItem(int itemID) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("inventory", "itemID = ?", new String[] {String.valueOf(itemID)}) > 0;
    }
}
