package com.zybooks.tandan_project2;
// Import Statements

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

// import constants
import static android.Manifest.permission.SEND_SMS;
import static android.content.pm.PackageManager.PERMISSION_GRANTED;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {
    private Context context;
    private Cursor cursor; // access database data
    private DBHelper dbHelper;  // database helper

    public InventoryAdapter(Context context, Cursor cursor, DBHelper dbHelper) {
        this.context = context;
        this.cursor = cursor;
        this.dbHelper = dbHelper;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView itemName, itemQuantity, decreaseButton, increaseButton, deleteButton;

        //  Find views by ID
        public ViewHolder(View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.textViewItemName);
            itemQuantity = itemView.findViewById(R.id.textViewItemQuantity);
            decreaseButton = itemView.findViewById(R.id.buttonDecrease);
            increaseButton = itemView.findViewById(R.id.buttonIncrease);
            deleteButton = itemView.findViewById(R.id.buttonDelete);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        if (!cursor.moveToPosition(position)) return;

        // get the column indices
        int idIndex = cursor.getColumnIndex("itemID");
        int nameIndex = cursor.getColumnIndex("name");
        int quantityIndex = cursor.getColumnIndex("quantity");

        // Check if any of the indices are -1, which means the column doesn't exist in the cursor
        if (idIndex == -1 || nameIndex == -1 || quantityIndex == -1) {
            Log.e("InventoryAdapter", "Column index error: Check column names.");
            return; // Exit this method by returning early to avoid further errors
        }
// fetch data from cursor
        int id = cursor.getInt(idIndex);
        String name = cursor.getString(nameIndex);
        int quantity = cursor.getInt(quantityIndex);

// populate view holder with data
        holder.itemName.setText(name);
        holder.itemQuantity.setText(String.valueOf(quantity));

// set up click listeners
        holder.increaseButton.setOnClickListener(v -> {
            dbHelper.updateItemQuantity(id, quantity + 1);
            refreshCursor();
        });

        holder.decreaseButton.setOnClickListener(v -> {
            if (quantity > 1) {
                dbHelper.updateItemQuantity(id, quantity - 1);
                refreshCursor();
            } else if (quantity == 1) {
                dbHelper.updateItemQuantity(id, 0);
                refreshCursor();
                sendSmsIfNeeded(name);
            }
        });

        holder.deleteButton.setOnClickListener(v -> {
            dbHelper.deleteItem(id);
            refreshCursor();
        });
    }

// send SMS if permission is granted
    private void sendSmsIfNeeded(String itemName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        String message;

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            String smsMessage = "Alert: Stock for " + itemName + " has reached zero.";
            smsManager.sendTextMessage("3108501988", null, smsMessage, null, null);
            message = "Stock for " + itemName + " has reached zero. An SMS notification has been sent.";
        } else {
            message = "Stock for " + itemName + " has reached zero. SMS permission not granted, no SMS notification was sent.";
        }

        builder.setTitle("Inventory Alert");
        builder.setMessage(message);
        builder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

// get item count
    @Override
    public int getItemCount() {
        return cursor != null ? cursor.getCount() : 0;
    }
// refresh cursor when data changes
    private void refreshCursor() {
        changeCursor(dbHelper.getAllItems());
    }
// update and notify adapter of changes
    public void changeCursor(Cursor newCursor) {
        if (cursor != null) cursor.close();
        cursor = newCursor;
        notifyDataSetChanged();
    }
}
